/* Database Systems, Coronel/Morris */
/* Type of SQL : MySQL */

CREATE DATABASE Ch08_SimpleCo;
USE Ch08_SimpleCo;
